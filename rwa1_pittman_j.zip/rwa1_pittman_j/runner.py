"""
Jerry Pittman, Jr., 117707120, jpittma1@umd.edu
ENPM809E: Python applications to robotics
Summer 2022
RWA1: runner.py
"""

from planner import generate_plan

if __name__ == '__main__':
    generate_plan()